./objects/funct_joystick.o: \
  ..\..\..\templates\09_sample_JOYSTICK\Source\joystick\funct_joystick.c \
  C:\Users\RSI_QUEST\AppData\Local\Arm\Packs\Keil\LPC1700_DFP\2.7.1\Device\Include\LPC17xx.h \
  Source\CMSIS_core\core_cm3.h \
  C:\Users\RSI_QUEST\AppData\Local\Arm\Packs\Keil\LPC1700_DFP\2.7.1\Device\Include\system_LPC17xx.h \
  ..\..\..\templates\09_sample_JOYSTICK\Source\joystick\joystick.h \
  ..\..\..\templates\09_sample_JOYSTICK\Source\joystick\..\led\led.h
