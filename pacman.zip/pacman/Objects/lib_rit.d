./objects/lib_rit.o: \
  ..\..\..\templates\09_sample_JOYSTICK\Source\RIT\lib_RIT.c \
  C:\Users\RSI_QUEST\AppData\Local\Arm\Packs\Keil\LPC1700_DFP\2.7.1\Device\Include\LPC17xx.h \
  Source\CMSIS_core\core_cm3.h \
  C:\Users\RSI_QUEST\AppData\Local\Arm\Packs\Keil\LPC1700_DFP\2.7.1\Device\Include\system_LPC17xx.h \
  ..\..\..\templates\09_sample_JOYSTICK\Source\RIT\RIT.h
